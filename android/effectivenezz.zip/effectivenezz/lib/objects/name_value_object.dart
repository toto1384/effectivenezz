
class NameValueObject{

  String name;
  int value;

  NameValueObject(this.name,this.value);
}