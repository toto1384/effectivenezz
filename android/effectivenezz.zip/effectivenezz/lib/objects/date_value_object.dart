

class DateValueObject{
  DateTime dateTime;
  int value;

  DateValueObject(this.dateTime,this.value);
}