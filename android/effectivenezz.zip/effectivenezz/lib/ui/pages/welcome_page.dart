import 'package:effectivenezz/data/drive_helper.dart';
import 'package:effectivenezz/ui/pages/track_page.dart';
import 'package:effectivenezz/ui/widgets/basics/distivity_drawer.dart';
import 'package:effectivenezz/ui/widgets/buttons/gsign_in_with_google_welcome_activity_button.dart';
import 'package:effectivenezz/utils/basic/utils.dart';
import 'package:effectivenezz/utils/basic/values_utils.dart';
import 'package:effectivenezz/utils/complex/widget_complex.dart';
import 'package:flutter/material.dart';


class WelcomePage extends StatefulWidget {

  final GoogleDriveHelper driveHelper;
  WelcomePage(this.driveHelper);
  @override
  _WelcomePageState createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {

  int currentPage = 0;

  @override
  Widget build(BuildContext context) {
    if(widget.driveHelper.currentUser!=null){
      launchPage(context, TrackPage());
    }


    return WillPopScope(
      onWillPop: ()=>customOnBackPressed(context),
      child: Scaffold(
        drawer: DistivityDrawer(),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              getWelcomePresentation(
                  context,
                  currentPage,
                  assetPaths: [
                    AssetsPath.timeIllustration,
                    AssetsPath.planningIllustration,
                    AssetsPath.metricIllustration,
                    AssetsPath.doctorIllustration
                  ], texts: [
                    "Track your time. Manage it",
                    "Plan your time in advance",
                    "Measure your time. Efficiently",
                    "Let the \'Time Doctor\' do the work for you(W.I.P.)"
                  ], onPageChanged: (i){
                    setState(() {
                      currentPage=i;
                    });
              }),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: GSignInWithGoogleWelcomeActivityButton(widget.driveHelper),
              ),
            ],
          ),
        )
      ),
    );
  }
}
