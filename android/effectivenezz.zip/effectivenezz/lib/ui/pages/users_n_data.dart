
import 'package:effectivenezz/ui/pages/iap_page.dart';
import 'package:effectivenezz/ui/widgets/basics/gwidgets/gicon.dart';
import 'package:effectivenezz/ui/widgets/basics/gwidgets/gtext.dart';
import 'package:effectivenezz/ui/widgets/specific/gwidgets/gdownloads_from_drive_list_tile.dart';
import 'package:effectivenezz/ui/widgets/specific/gwidgets/gsave_to_drive_list_tile.dart';
import 'package:effectivenezz/ui/widgets/specific/gwidgets/gsign_in_out_list_tile.dart';
import 'package:effectivenezz/utils/basic/utils.dart';
import 'package:effectivenezz/utils/basic/values_utils.dart';
import 'package:effectivenezz/utils/complex/widget_complex.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../main.dart';

class UsersNData extends StatefulWidget {
  @override
  _UsersNDataState createState() => _UsersNDataState();
}

class _UsersNDataState extends State<UsersNData> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: getAppBar("Users and Data",backEnabled: true,context: context),
      body: Column(
        children: <Widget>[
          ListTile(
            leading: CircleAvatar(
              maxRadius: 20,
              backgroundColor: MyColors.color_yellow,
            ),
            title: GText(MyApp.dataModel.driveHelper.currentUser!=null?MyApp.dataModel.driveHelper.currentUser.displayName:"Logged off"),

          ),
          Divider(),
          GSignInOutListTile(),
          GSaveToDriveListTile(),
          GDownloadsFromDriveListTile(),
          ListTile(
            title: GText("Delete everything"),
            leading: GIcon(Icons.delete_forever),
            onTap: (){
              deleteDb(context);
            },

          ),
          if(!kIsWeb)ListTile(
            title: GText("Pricing"),
            leading: GIcon(Icons.monetization_on),
            onTap: (){
              launchPage(context, IAPScreen());
            },

          ),
        ],
      ),
    );
  }
}
