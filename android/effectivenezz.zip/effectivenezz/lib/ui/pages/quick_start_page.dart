import 'package:effectivenezz/main.dart';
import 'package:effectivenezz/objects/activity.dart';
import 'package:effectivenezz/objects/calendar.dart';
import 'package:effectivenezz/objects/scheduled.dart';
import 'package:effectivenezz/objects/task.dart';
import 'package:effectivenezz/ui/pages/track_page.dart';
import 'package:effectivenezz/ui/widgets/basics/distivity_radio_group.dart';
import 'package:effectivenezz/ui/widgets/basics/distivity_restart_widget.dart';
import 'package:effectivenezz/ui/widgets/basics/gwidgets/gbutton.dart';
import 'package:effectivenezz/ui/widgets/basics/gwidgets/gswitchable.dart';
import 'package:effectivenezz/ui/widgets/basics/gwidgets/gtext.dart';
import 'package:effectivenezz/ui/widgets/basics/gwidgets/gtext_field.dart';
import 'package:effectivenezz/ui/widgets/buttons/gsign_in_with_google_welcome_activity_button.dart';
import 'package:effectivenezz/ui/widgets/specific/gwidgets/scheduled/gdate_time_edit_widget_for_scheduled.dart';
import 'package:effectivenezz/utils/basic/date_basic.dart';
import 'package:effectivenezz/utils/basic/typedef_and_enums.dart';
import 'package:effectivenezz/utils/basic/utils.dart';
import 'package:effectivenezz/utils/basic/values_utils.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';




class QuickStartPage extends StatefulWidget {
  @override
  _QuickStartPageState createState() => _QuickStartPageState();
}

class _QuickStartPageState extends State<QuickStartPage> {

  Scheduled sleepScheduled = Scheduled(
    durationInMins: 8*60,
    isParentTask: false,
    repeatRule: RepeatRule.EveryXDays,
    repeatValue: 1,
    parentId: 1000,
  );
  bool addReview = true;
  List<MainOccupationType> mainOccupationTypes = [];

  TextEditingController activityDurationMinutesTEC= TextEditingController();
  TextEditingController activityNameTEC = TextEditingController();



  PageController pageController = PageController(initialPage: 0,);
  
  int pageIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Visibility(
        visible: pageIndex==0,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: [
            GText("Already an user?"),
            GButton("Log in", onPressed: (){
              MyApp.dataModel.driveHelper.handleSignIn().then((v){
                DistivityRestartWidget.restartApp(context);
              });
            },variant: 2),
          ],
        ),
      ),

      floatingActionButton: pageIndex==3?null:FloatingActionButton.extended(onPressed: ()async{
        pageController.
          animateToPage((pageIndex+1), duration: Duration(milliseconds: 500), curve: Curves.easeInOut);
        setState(() {
          pageIndex++;
        });
      },backgroundColor: MyColors.color_black, label: GText(pageIndex==2?"Finish":"Next(${pageIndex+1}/3)")),

      body: PageView(
        controller: pageController,
        physics: NeverScrollableScrollPhysics(),
        children: [
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: GText("I work on :",textType: TextType.textTypeGigant),
                ),
                RosseRadioGroup(
                  isBig: true,
                  items: {
                    "9-5 Job":mainOccupationTypes.contains(MainOccupationType.values[0]),
                    "Freelance":mainOccupationTypes.contains(MainOccupationType.values[1]),
                    "Side Hustle/Job":mainOccupationTypes.contains(MainOccupationType.values[2]),
                  },
                  onSelected: (i,s){
                    setState(() {
                      if(mainOccupationTypes.contains(MainOccupationType.values[i])){
                        //contains
                        mainOccupationTypes.remove(MainOccupationType.values[i]);
                      }else{
                        mainOccupationTypes.add(MainOccupationType.values[i]);
                      }
                    });
                  },
                ),
                GText("(select 1 or more)")
              ],
            ),
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GText("I go to sleep at:",textType: TextType.textTypeTitle),
                GDateTimeEditWidgetForScheduled(onScheduledChange: (sch){
                  setState(() {
                    sleepScheduled=sch;
                  });
                },isStartTime: true,scheduled: sleepScheduled,text:'',onlyTime: true,),
                GSwitchable(text: "Schedule daily review(an essential habit for a productive day)",
                    checked: addReview, onCheckedChanged: (b){
                      setState(() {
                        addReview=b;
                      });
                    }, isCheckboxOrSwitch: true
                ),
              ],
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.all(15),
                  child: kIsWeb?Wrap(
                    direction: Axis.horizontal,
                    children: [
                      GText('What\'s that one activtiy that if I do everyday for',),
                      Container(
                        width: 100,
                        child: Padding(
                          padding: const EdgeInsets.all(2),
                          child: GTextField(
                              activityDurationMinutesTEC, hint: 'hours',small: true),
                        ),
                      ),
                      GText(' hours will change my life in 6 months'),
                    ],
                  ):Text.rich(
                    TextSpan(children: <InlineSpan>[
                      TextSpan(text: 'What\'s that one activtiy that if I do everyday for',style: TextStyle(
                        color: Colors.white,
                        fontWeight: TextType.textTypeNormal.fontWeight,
                        fontSize: TextType.textTypeNormal.size,
                      ),),
                      WidgetSpan(
                        alignment: PlaceholderAlignment.middle,
                        child: Container(
                          width: 100,
                          child: Padding(
                            padding: const EdgeInsets.all(2),
                            child: GTextField(
                                activityDurationMinutesTEC, hint: 'hours',small: true),
                          ),
                        ),),
                      TextSpan(text: ' hours will change my life in 6 months',style: TextStyle(
                        color: Colors.white,
                        fontWeight: TextType.textTypeNormal.fontWeight,
                        fontSize: TextType.textTypeNormal.size,
                      )),
                    ],),textAlign: TextAlign.center,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: GTextField(activityNameTEC,hint: 'Activity name',),
                ),
              ],
            ),
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GText("Time management shouldn\'t be that hard and STRICT. So we\'ve created a simple routine "
                    "for you and you will be notified before each activity.",textType: TextType.textTypeSubtitle),
                GSignInWithGoogleWelcomeActivityButton( MyApp.dataModel.driveHelper),
                GText("(and continue)",)
              ],
            ),
          ),
        ],
      ),
    );
  }
  save()async{
    //cals
    await MyApp.dataModel.eCalendar(-1, ECalendar(
      name: 'Body',
      color: Colors.brown,
      parentId: -1,
      show: true,
      themesEnd: [],
      themesStart: [],
      value: 0,
      id: 1000,
    ), context, CUD.Create,);//body
    await MyApp.dataModel.eCalendar(-1, ECalendar(
      name: 'Habits',
      color: Colors.green,
      parentId: -1,
      show: true,
      themesEnd: [],
      themesStart: [],
      value: 0,
      id: 1001,
    ), context, CUD.Create);//habits
    await MyApp.dataModel.eCalendar(-1, ECalendar(
        name: 'Work',
        value: 10000,
        color: Colors.red,
        show: true,
        themesEnd: [],
        themesStart: [],
        parentId: -1,
        id: 1010
    ), context, CUD.Create);//work
    await MyApp.dataModel.eCalendar(-1, ECalendar(
      name: 'Addictions',
      value: -1000,
      parentId: -1,
      themesStart: [],
      themesEnd: [],
      show: true,
      color: Colors.grey,
      id: 1005,
    ), context, CUD.Create);
    //

    //addictions
    await MyApp.dataModel.activity(-1, Activity(
        value: -1000,
        name: 'Social Media',
        parentCalendarId: 1005,
        trackedEnd: [],
        tags: [],
        trackedStart: [],
        color: Colors.grey,
        valueMultiply: false,
        icon: Icons.phone_android
    ), context, CUD.Create);
    await MyApp.dataModel.activity(-1, Activity(
        value: -1000,
        name: 'Netflix/TV',
        parentCalendarId: 1005,
        trackedEnd: [],
        tags: [],
        trackedStart: [],
        valueMultiply: false,
        color: Colors.grey,
        icon: Icons.tv
    ), context, CUD.Create);
    await MyApp.dataModel.activity(-1, Activity(
      value: -100,
      name: 'Gaming',
      parentCalendarId: 1005,
      trackedEnd: [],
      tags: [],
      color: Colors.grey,
      trackedStart: [],
      valueMultiply: false,
      icon: Icons.gamepad,
    ), context, CUD.Create);
    //

    //sleep
    await MyApp.dataModel.activity(-1, Activity(
        name: "Sleep",
        parentCalendarId: 1000,
        value: 10,
        trackedEnd: [],
        tags: [],
        color: Colors.brown,
        trackedStart: [],
        valueMultiply: false,
        icon: Icons.hotel,
        id: 1000
    ), context, CUD.Create,addWith: sleepScheduled);//sleep

    //activity
    if(activityNameTEC.text!=''&&activityDurationMinutesTEC.text!='')
      await MyApp.dataModel.activity(-1, Activity(
        trackedEnd: [],
        tags: [],
        trackedStart: [],
        valueMultiply: false,
        name: activityNameTEC.text,
        value: 1000,
        color: Colors.red,
        parentCalendarId: 1010,
        id: 11,
        icon: Icons.work,
      ), context, CUD.Create,addWith: Scheduled(
        isParentTask: false,
        durationInMins: int.parse(activityDurationMinutesTEC.text)*60,
        repeatValue: 1,
        repeatRule: RepeatRule.EveryXDays,
        parentId: 11,
        startTime: (sleepScheduled.getEndTime()??getTodayFormated()).add(Duration(hours: 1)),
      ));//activity
    if(addReview)await MyApp.dataModel.task(-1, Task(
        id: 12,
        parentId: 1001,
        value: 10000,
        name: 'Review your day',
        valueMultiply: false,
        trackedStart: [],
        tags: [],
        trackedEnd: [],
        isParentCalendar: true,
        checks: [],
        color: Colors.blue,
        description: "ANSWER THESE QUESTIONS ON A PIECE OF PAPER!\n\n\n"
            "Look at your calendar,Have you spend your week on the right things?\nWhy?\n"
            "Did you followed your schedule?\nIf not, Why?\n"
            "Look at your metrics!\nWere you focused?\nWas your time of great value today?\n\n"
            "So, are you happy with your current results?\nWhat you can change to do better?\n"
            "How much did you spend on addictions?\nHow can you become more disciplined to do less of them?\n"
            "What are you doing different from your role models and for those that accomplish your goals?\n"
            "How much time did you spend building something that no one asked for?\n"
            "If you had a heart attack tomorrow and have to work only 2 hours a day, what will you work on?\n"
            "Has today added anything of value to your stock of knowledge or state of mind?\n"
            "Think of the most successful person who solved the biggest problem you have right now."
            " How did he did it and what advice he'd give to you?\n"
            "How can I solve the biggest flaw in myself that is holding me from achieving my goals\n"
            "Consider how many people work for years to get a 15% raise when they could quickly switch to"
            " a new job that pays 25% better. - How are you doing something similar in your life? How can you work smarter?\n"
    ), context,CUD.Create,addWith: Scheduled(
        repeatRule: RepeatRule.EveryXDays,
        repeatValue: 1,
        durationInMins: 20,
        isParentTask: true,
        startTime: sleepScheduled.startTime.subtract(Duration(minutes: 20)),
        parentId: 12
    ));//review

    mainOccupationTypes.forEach((element) async {
      switch(element){

        case MainOccupationType.NineToFive:
          await MyApp.dataModel.activity(-1, Activity(
            trackedEnd: [],
            tags: [],
            trackedStart: [],
            valueMultiply: false,
            name: activityNameTEC.text,
            value: 1000,
            color: Colors.red,
            parentCalendarId: 1010,
            id: 11,
            icon: Icons.work,
          ), context, CUD.Create,addWith: Scheduled(
            isParentTask: false,
            durationInMins: int.parse(activityDurationMinutesTEC.text)*60,
            repeatValue: 1,
            repeatRule: RepeatRule.EveryXDays,
            parentId: 11,
            startTime: (sleepScheduled.getEndTime()??getTodayFormated()).add(Duration(hours: 1)),
          ));
          break;
        case MainOccupationType.Freelance:
          // TODO: Handle this case.
          break;
        case MainOccupationType.Business:
          // TODO: Handle this case.
          break;
      }
    });

    launchPage(context, TrackPage());
  }

}

enum MainOccupationType{
  NineToFive,Freelance,Business
}
