import 'package:flutter/material.dart';

class TodaySMetricsPage extends StatefulWidget {
  @override
  _TodaySMetricsPageState createState() => _TodaySMetricsPageState();
}

class _TodaySMetricsPageState extends State<TodaySMetricsPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
