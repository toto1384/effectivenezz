import 'package:effectivenezz/ui/pages/welcome_page.dart';
import 'package:effectivenezz/ui/widgets/basics/gwidgets/gicon.dart';
import 'package:effectivenezz/ui/widgets/basics/gwidgets/gtext.dart';
import 'package:effectivenezz/utils/basic/utils.dart';
import 'package:flutter/material.dart';

import '../../../../main.dart';

class GSignInOutListTile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: GIcon(MyApp.dataModel.driveHelper.currentUser==null?Icons.chevron_right:Icons.chevron_left),
      title: GText(MyApp.dataModel.driveHelper.currentUser==null?'Sign in':'Sign out'),
      onTap: ()async{
        if(MyApp.dataModel.driveHelper.currentUser==null){
          launchPage(context, WelcomePage(MyApp.dataModel.driveHelper));
        }else{
          await MyApp.dataModel.driveHelper.handleSignOut();
          launchPage(context, WelcomePage(MyApp.dataModel.driveHelper));
        }
      },
    );
  }
}
