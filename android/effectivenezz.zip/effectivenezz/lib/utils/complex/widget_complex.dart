import 'package:demoji/demoji.dart';
import 'package:effectivenezz/ui/pages/quick_start_page.dart';
import 'package:effectivenezz/ui/widgets/basics/gwidgets/gbutton.dart';
import 'package:effectivenezz/ui/widgets/basics/gwidgets/gicon.dart';
import 'package:effectivenezz/ui/widgets/basics/gwidgets/gtext.dart';
import 'package:effectivenezz/ui/widgets/basics/platform_svg.dart';
import 'package:effectivenezz/ui/widgets/specific/distivity_animated_list_obj.dart';
import 'package:effectivenezz/ui/widgets/specific/gwidgets/ginfo_icon.dart';
import 'package:effectivenezz/utils/basic/date_basic.dart';
import 'package:effectivenezz/utils/basic/overflows_basic.dart';
import 'package:effectivenezz/utils/basic/typedef_and_enums.dart';
import 'package:effectivenezz/utils/basic/utils.dart';
import 'package:effectivenezz/utils/basic/values_utils.dart';
import 'package:effectivenezz/utils/basic/widgets_basic.dart';
import 'package:effectivenezz/utils/distivity_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_xlider/flutter_xlider.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../../main.dart';
import '../date_n_strings.dart';
import 'overflows_complex.dart';


getWelcomePresentation(BuildContext context, int currentPage,
    {@required List<String> assetPaths, @required List<
        String> texts, @required Function(int) onPageChanged}) {
  PageController pageController = PageController(initialPage: currentPage);

  return Column(
    crossAxisAlignment: CrossAxisAlignment.center,
    mainAxisSize: MainAxisSize.min,
    children: <Widget>[
      Padding(
        padding: const EdgeInsets.all(10),
        child: Container(
          height: 450,
          child: PageView(
            onPageChanged: onPageChanged,
            children: List<Widget>.generate(assetPaths.length, (index) =>
                Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: Image.asset(
                        assetPaths[index], width: 300, height: 300,),
                    ),
                    getSubtitle(texts[index],),
                  ],
                )),
            controller: pageController,
          ),
        ),
      ),
      Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: List<Widget>.generate(assetPaths.length, (index) =>
            Padding(
              padding: const EdgeInsets.all(5),
              child: CircleAvatar(
                backgroundColor: index == currentPage ? MyColors
                    .color_yellow : MyColors.color_gray_lighter,
                radius: 5,),
            )),
      ),

    ],
  );
}

Widget getAppBar(String title,
    {bool backEnabled,
      bool centered,
      BuildContext context,
      bool drawerEnabled,
      Widget trailing,
      Widget subtitle,
      bool smallSubtitle,
      String tooltip,
      GlobalKey key,
    }) {
  if (centered == null) {
    centered = false;
  }

  if (smallSubtitle == null) {
    smallSubtitle = true;
  }

  if (drawerEnabled == null) {
    drawerEnabled = false;
  }
  if (backEnabled == null) {
    backEnabled = false;
  }
  return PreferredSize(
    key: key,
    preferredSize: Size(MyApp.dataModel.screenWidth, smallSubtitle ? 100 : 150),
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: (Align(
        alignment: centered ? Alignment.bottomCenter : Alignment.bottomLeft,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              brightness: Brightness.dark,
              leading: drawerEnabled?IconButton(
                icon: GIcon(Icons.menu,),
                onPressed: () {
                  DistivityPageState.customKey.openDrawer();
                },
              ):backEnabled?IconButton(
                icon: GIcon(Icons.chevron_left), onPressed: () {
                Navigator.pop(context);
              },):Container(),
              title: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Flexible(child: GText(title, textType: TextType.textTypeTitle,)),
                      Visibility(child: GInfoIcon( tooltip),
                        visible: tooltip != null,),
                    ],
                  ),
                  if(subtitle != null && smallSubtitle)
                    subtitle
                ],
              ),
            ),
            if(!smallSubtitle && subtitle != null)
              subtitle
          ],
        ),
      )),
    ),
  );
}

getEmojiSlider(double value, Function(double) onChanged,double size){
  if(size==null||size<=0)size=100;
  return StatefulBuilder(
    builder: (ctx,ss){
      return Container(
        width: size,
        height: 100,
        child:  FlutterSlider(
          values: [0,1,2,3,4],
          min: 0,
          max:4,
          onDragCompleted: (ind,low,high){
            onChanged(value);
          },
          trackBar: FlutterSliderTrackBar(
            activeTrackBarHeight: 10,
            inactiveTrackBarHeight: 10,
            activeTrackBar: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              color: Colors.white,
            ),
            inactiveTrackBar: BoxDecoration(
              color: MyColors.color_gray_lighter,
              borderRadius: BorderRadius.circular(15)
            )
          ),

          onDragging: (ind,low,high){
            ss((){
              value=low.toDouble();
            });
          },
          decoration: BoxDecoration(color: Colors.transparent),
//          fixedValues: [
//            FlutterSliderFixedValue(value: 0,percent: 0),
//            FlutterSliderFixedValue(value: 1,percent: 25),
//            FlutterSliderFixedValue(value: 2,percent: 50),
//            FlutterSliderFixedValue(value: 3,percent: 75),
//            FlutterSliderFixedValue(value: 4,percent: 100)
//          ],
//          lockHandlers: true,
          tooltip: FlutterSliderTooltip(
            alwaysShowTooltip: false,
            custom: (val)=>Center(),
          ),
          handlerHeight: TextType.textTypeGigant.size+15,
          handlerWidth: TextType.textTypeGigant.size+15,

          handler: FlutterSliderHandler(
            decoration: BoxDecoration(color: Colors.transparent),
            child: GText(getEmojiVal(value.toInt()),textType: TextType.textTypeGigant)
          ),
        ),
      );
    },
  );
}

getEmojiVal(int value){
  switch(value){
    case 0:return Demoji.angry;break;
    case 1:return Demoji.worried;break;
    case 2:return Demoji.slightly_frowning_face	;break;
    case 3:return Demoji.grinning	;break;
    case 4:return Demoji.smiling_face_with_three_hearts	;break;
  }
}

getTabBar({@required List<String> items, @required List<
    int> selected, Function(int, bool) onSelected,int variant}) {
  return SingleChildScrollView(
    scrollDirection: Axis.horizontal,
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(items.length, (index) {
        bool isSelected = selected.contains(index);
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: (
            GButton(
              items[index],
              variant: isSelected ? 1 : 2,
              onPressed: () {
                onSelected(index, !isSelected);
              },
            )
          ),
        );
      }),
    ),
  );
}

upcomingTasksAndActivities(BuildContext context, ScrollController controller,
    DateTime selectedDate,) {

    return DistivityAnimatedListObj(
      scrollController: controller,
      getHeader: (ctx,ind){
        DateTime listDate = ind==7?null:getTodayFormated().add(Duration(days: ind));
        return Container(
          child: Row(
            children: <Widget>[
              getSubtitle(ind == 7 ? "No date" : getDateName(listDate)),
            ],
          ), color: MyColors.color_black_darker,
        );
      },
      getHeaderSelectedDate: (ind){
        return [ind==7?null:getTodayFormated().add(Duration(days: ind))];
      },
      headerItemCount: 8,
      isObjectSuitableForHeader: (item, ind){
        DateTime listDate = ind==7?null:getTodayFormated().add(Duration(days: ind));
        if (item.getScheduled(context)[0].isOnDates(context, [listDate])) {
          return true;
        }return false;
      },
      whatToShow: WhatToShow.All,
      areMinimal: false,
    );
}

bool showing = false;

sortByMoneyTasksAndActivities(BuildContext context, ScrollController controller,
    DateTime selectedDate,) {

  return StatefulBuilder(
    builder: (context, ss) {
      return DistivityAnimatedListObj(
        getHeader: (ctx,ind){
          return Container(
            child: Row(
              children: <Widget>[
                getSubtitle("\$${formatDouble(figures(15-ind.toDouble()))}"),
              ],
            ), color: MyColors.color_black_darker,
          );
        },
        additionalButton: Container(
          width: MediaQuery.of(context).size.width,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: GButton(showing?'Hide low value entries':'Show low value entries', onPressed: (){
                if(showing==true){
                  ss((){
                    showing=false;
                  });
                  return;
                }
                showDistivityDialog(context, actions: [
                  GButton('Show', onPressed: (){
                    ss((){
                      showing=!showing;
                    });
                    Navigator.pop(context);
                  },variant: 2),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: GButton('Return to excellence', onPressed: ()=>Navigator.pop(context)),
                  ),
                ], title: 'Show low value entries?', stateGetter: (ctx,ss){
                  return Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      GText('Below 0\$ activities will only make you feel good and will not make you happy. Time for yourself'
                        ' should be about your relatives, journaling, reading, exercising and meditation. These will actually make '
                        'you happy. \n Watch this video, it explains this concept better'),
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: YoutubePlayer(
                          controller: YoutubePlayerController(
                            initialVideoId: 'u_zMDLQgFrM',
                            flags: YoutubePlayerFlags(
                              autoPlay: false
                            )
                          ),

                        ),
                      ),
                    ],
                  );
                });
              }),
            ),
          ),
        ),
        getHeaderSelectedDate: (ind){
          return [selectedDate];
        },
        headerItemCount: showing?15:9,
        isObjectSuitableForHeader: (item, ind){
          if(item.value == figures(15.0-ind.toDouble()).toInt()){
            return true;
          }return false;
        },
        whatToShow: WhatToShow.All,
        areMinimal: false,
        scrollController: controller,
      );
    }
  );
}





